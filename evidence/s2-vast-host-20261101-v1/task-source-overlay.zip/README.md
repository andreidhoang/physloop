# PhysLoop

PhysLoop builds and measures NVIDIA's Alpamayo **teacher → Thor-student** path for autonomous driving. It has two parts:
- **the gate**, an open release gate that runs paired, stratified, validity-checked closed-loop verdicts on AlpaSim;
- **PhysLoop-AV**, the loop the gate measures:
  - NVIDIA's own 2B student against its 10B teacher;
  - closed-loop RL of the teacher;
  - on-policy correction of the student and its reasoning-budget curve;
  - real-time serving on Jetson AGX Thor with hardware-in-the-loop;
  - optional shadow mode in Ho Chi Minh City.

The gate answers one question about the model that actually ships:

> Did distillation, quantization or RL make the deployable model worse, and where?

**Why it is needed** (verified 2026-10-25):
- NVIDIA has announced Alpamayo 2 Edge, a 2B model for DRIVE AGX Thor at 10 Hz. It has also put up a public 10B → 2B distillation recipe (alpamayo-recipes PR #42, unmerged). Both report open-loop error and latency only. Nobody has published how the student drives in closed loop.
- NVIDIA's own 2B students run at 171 ms (FP8) on DRIVE AGX Thor, so what it takes to reach 10 Hz is an open, measurable question.
- No open tool gives a paired, stratified go/no-go verdict between two Alpamayo checkpoints. NVIDIA's Alpamayo 1.5 card moved its AlpaSim score from 0.81 to 1.37 with unchanged weights.
- AlpaGym has published no closed-loop RL gains.

## The loop (systems view)

```
        ┌──────────────────────────────────────────────────────────┐
        │                REINFORCING LOOP (data flywheel)           │
        ▼                                                          │
 [fleet-style logs] → [NuRec reconstruction] → [AlpaSim closed-loop]│
                                                   │               │
                       [Teacher: Alpamayo 1.5 10B / 2 Super ~34B]  │
                                   │ distill / RL / quantize       │
                                   ▼                               │
                     [Student 2B (Edge), FP8/NVFP4, Thor]          │
                                   ▼                               │
                    ╔════════════════════════════╗                 │
                    ║  RELEASE GATE (this repo)   ║ ◄── BALANCING   │
                    ║  paired + stratified +      ║     LOOP        │
                    ║  validity + reliability     ║                 │
                    ╚════════════════════════════╝                 │
                                   │ go                            │
                                   ▼                               │
          [Jetson AGX Thor → HIL → shadow mode (open-loop)] ───────┘
```

The gate is the balancing loop. Without it, the flywheel optimizes whatever the metric rewards (Goodhart), and RL is the strongest metric-exploiter we own.

## Status
- Standalone and active. Plan v4.1 dated 2026-10-27 (DECISIONS D-015), amending plan v4 of 2026-10-25 (D-012).
- The target role's line-by-line evidence contract (NVIDIA JR2010863) is `docs/05_ROLE_MAPPING.md` §3.
- Current work: S2 free preparation after the CPU-only S1 decision core; D = 2026-10-26.
- S1 engineering qualification completed on 2026-10-31 under D-016: CPU-only gate, strict pairing, road clustering, finite-look stopping, tests, and power tables.
- The operational gate uses conservative bounded-road inference. Tango/bootstrap and classical Gaussian sequential designs are separately labelled references, not the authorization method. The target is an equal-road population mean.
- D-018 adopts agent-owned evaluator engineering and the nested $100 pilot / $1,200 S2 / $2,500 project cloud caps. Concrete rental, funding and license actions remain pending approval; see [the approval packet](docs/S2_RENTAL_APPROVAL.md).
- S2 free preparation is implemented: offline preflight, source-pinned adapter, geometry-helper controls, draft manifests and implementation plan. GPU runs remain gated on the recorded budget and S2 protocol. No real-model result has been measured.

## Run the gate

```sh
uv sync --locked
uv run --frozen pytest -q
uv run --frozen python -m gate power
uv run --frozen python -m gate verdict comparison.json
uv run --frozen python -m gate qualify --output evidence/s1-local-reproduction
```

The verdict command accepts schema-version-1 raw arm records through `gate.api.parse_request`; `tests/test_api.py` contains complete examples. An invalid comparison exits with an input error. GO, NO-GO and INSUFFICIENT are valid results. Qualification must run from a source checkout; it refuses to overwrite an existing evidence directory. A different trial count or seed is a diagnostic run, not the registered qualification.

- [S1 implementation contract](docs/S1_IMPLEMENTATION.md)
- [Mathematical argument and assumptions](docs/S1_CORRECTNESS.md)
- [Recorded qualification report](evidence/s1-20261031-autonomous-v1/report.md)
- [Power tables](evidence/s1-20261031-autonomous-v1/power_tables.json)
- [S1 handoff and reproduction](docs/S1_HANDOFF.md)

The evidence is synthetic. Finite tests do not establish unconditional correctness. The proved error bounds assume independent complete road clusters, fixed sampling/strata and the registered look schedule. Reduced power is a measured tradeoff: noisy equivalent configurations can remain INSUFFICIENT even when a Gaussian planning calculation looks favorable.

## Start here

S2 handoff: [engineering specification](docs/S2_ENGINEERING_SPEC.md), [implementation and budget plan](docs/S2_IMPLEMENTATION_PLAN.md), and [research/agent operating model](docs/RESEARCH_OPERATING_MODEL.md). Check a draft with `uv run --frozen python -m gate.s2 preflight experiments/S2_PILOT_DRAFT.json`; its blocked result is intentional. Generate a fresh software verification record with `uv run --frozen python -B scripts/verify_s2.py --output evidence/s2-NEW-UNIQUE-ID`.

1. `DOC_AUTHORITY.md` — which document wins.
2. `docs/00_START_HERE.md` — reading order, the build rituals, and where we are.
3. `docs/02_PHYSLOOP_PLAN.md` — what we build, in what order, and what kills it.

When working with Claude Code, run `/reread` before every build session.
