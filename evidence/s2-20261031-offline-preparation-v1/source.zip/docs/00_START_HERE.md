# Start here

## Reading order
On the first read, read all of it. Every session, re-read steps 1, 3, 5 and 6.

1. `../DOC_AUTHORITY.md` — 2 minutes. Which document wins.
2. `01_SYSTEM_DESIGN.md` — the system map, the three system laws, the thirteen core concepts.
3. `02_PHYSLOOP_PLAN.md` — **the plan**: deliverables G1–G9, stages S1–S8, budget tiers, allowed claims, kill checks, risks, open decisions.
4. `03_MASTERY_PLAN.md` — the skill pillars, the curriculum for each stage, the mastery gates, skill coverage.
5. `DECISIONS.md` — what was decided and why. Newest entries are at the bottom.
6. `../journal/` — the last entry: what was tested, what happened, the next hypothesis. Created at the first after-build ritual.

Reference, when needed:
- `04_CORE_PLAN_TECHNICAL.md` — verified model, hardware and cost facts, plus the preserved 22-Sep predictions.
- `05_ROLE_MAPPING.md` — live NVIDIA postings, and the JR2010863 evidence contract (§3).
- `research/2026-10-27-role-alignment/` — the seven research lanes, the report, the verification ledger and the arithmetic check behind plan v4.1.
- `research/2026-10-25-teacher-to-thor/` — the decision input, the review and the verification ledger behind plan v4.
- `research/2026-10-03-verification/` — the evidence and claim ledger behind plan v3, still valid where not superseded.

## The before-build ritual (do not skip)
1. Name the stage (S1–S8) and the deliverable (G1–G9) that today's work serves.
2. Do the stage's curriculum exercise in `03` §4 if you have not done it yet.
3. Open or create `../experiments/<date>-<slug>.md` from `TEMPLATE.md`. Write the hypothesis, the mechanism (derived, with numbers), the falsifiable prediction with a number, the scope, the kill criterion, and the metric-to-decision rule. The prediction comes after the mechanism is derived, never before.
4. Estimate the cost (GPU-hours × the current price; re-price at every stage start) and write it down.
5. Check the gates:
   - Does this spend money (P-005; hardware: P-002, P-006)?
   - Does it publish a number derived from PAI-AV or NuRec (KC-L, P-004)?
   - Does it publish weights or labels trained on such data (KC-L2)?
6. Only then: code.

## The after-build ritual
1. Reconcile prediction against measurement in the experiment file. Explain every miss causally, and keep negative results.
2. Write three sentences in `../journal/<date>.md`: what was tested, the result (with the number), and the next hypothesis.
3. If anything changed a decision, append it to `DECISIONS.md`.

## Where we are (update this block when the stage changes)
- **Status:** standalone and active (D-009). **Plan v4.1 adopted on 2026-10-27 (D-015)**, amending v4 (D-012, 2026-10-25): the teacher → student → Thor loop, with the gate as its measuring instrument. v4.1 adds:
  - corrections: S2 runs unseeded replicates unless a seeded mode is recorded; the contamination rule and the S4 estimator text are fixed;
  - savings: NVIDIA's expert CUDA graph, PR #42's one-node trainer, AlpaSim's own S7 mechanisms;
  - one-node evidence for JR2010863 inside the existing stages (`02` §0.1, `05` §3).

  S1 engineering qualification completed on 2026-10-31 under D-016. The gate, independent tests, synthetic Monte Carlo and power tables now exist. The operational method is conservative bounded-road inference; the historical Tango/bootstrap and Gaussian designs remain labelled references. See `S1_HANDOFF.md` for evidence and limits.
- **Stage:** **S1 technically qualified; S2 free preparation implemented; S2 runs not admitted.** KC-1's amended statistical software check passed on 2026-10-31, before its 2026-11-02 check date. D-017 covers S2 specifications, offline preflight/adapter/CLI, exact public geometry-helper tests and engineering plans. See `S2_ENGINEERING_SPEC.md` and `S2_IMPLEMENTATION_PLAN.md`; actual instrument qualification is still pending. No GPU run is authorized until P-005 and the applicable S2 protocol are recorded. Huy's mastery and actual weekly hours are not inferred from agent delivery. D remains 2026-10-26.
- **Next output:**
  - review the completed local gate v0 and synthetic evidence, then Huy's publication action;
  - the upstream issue draft in `S1_UPSTREAM_ISSUE_DRAFT.md`, not sent;
  - record the pilot decisions using `../experiments/S2_PILOT_DRAFT.json`; after pilot cost evidence, freeze the full protocol in `../experiments/S2_FULL_DRAFT.json`; the older schema-v1 manifest is historical;
  - record P-005 and P-003 before renting or forecasting the remaining windows.
- **Dated check:** **KC-E checked on 2026-10-31; not passed.** The checked public NVIDIA model catalog exposed 1.5, R1 and Super, but no verified Edge weights/license. See `research/2026-10-31-s2-models-budget.md`; repeat at S3 admission. The existing conditional S4-first path remains available; no substitute student is adopted.
- **Open decisions:**
  - P-002, the Jetson AGX Thor purchase: blocks S6–S7.
  - P-003, weekly hours: re-forecast at KC-1.
  - P-004, the license request to NVIDIA (§3 numbers, §4.6 weights): blocks every public number from S2 on. Sending it early is cheap.
  - P-005, the cloud budget tier: needed before any S2 spend.
  - P-006, the shadow-mode go: blocks S8.
  - P-012 to P-019, gated v4.1 additions; none blocks S1–S2:
    - P-012: multi-node;
    - P-013 and P-014: the traffic and renderer legs;
    - P-015: the batched driver;
    - P-016: a third RL arm;
    - P-017: a PR #42 pilot student;
    - P-018: a few-step expert;
    - P-019: one C++ driver for two targets.
- **Do not:**
  - download PAI-AV or NuRec before S2 starts (license term §8);
  - start S2 runs before the challenge closes on 2026-10-31. NVIDIA ties its withheld simulation choices to its next release (AlpaSim #224), so check for one at S2's start;
  - start any S2 run before its branch, seed mode, Harmonizer state and run method are pre-registered in `experiments/`;
  - file an upstream PR without re-checking NVIDIA's latest release, or one that competes with an offered PR (#208);
  - register for the 2026 challenge (it needs an organization email).
